<?php
define('MSG_CODE_NOT_REGISTER_DEVICEID', 3); // Chua dang ky DEVICE ID len he thong

define('MSG_CODE_FALSE', 0); // Co loi xay ra
define('MSG_CODE_TRUE', 1); // Ko loi

define('MSG_CODE_LOCK', 2); // Tai khoan bi khoa

define('MSG_CODE_INVALID_TOKEN', -1); // Sai token
define('MSG_CODE_PAYMENT', -2); // Het $ su dung
define('MSG_CODE_500', 500); // Loi he thong
