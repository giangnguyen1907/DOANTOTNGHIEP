<?php
define('PS_TEXT_INVALID_TOKEN', 'Phiên làm việc đã hết. Bạn cần đăng nhập lại.');
define('PS_TEXT_INVALID_PAYMENT', 'Tài khoản của bạn đã hết. Hãy nạp tiền để tiếp tục sử dụng');
define('PS_TEXT_ERROR_500', 'Hệ thống gặp lỗi\nHãy thực hiện lại sau ít phút nữa');