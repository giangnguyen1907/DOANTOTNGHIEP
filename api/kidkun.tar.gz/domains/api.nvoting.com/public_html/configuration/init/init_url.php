<?php
define('PS_CONST_URL_APIS', 'https://api.nvoting.com');

// Url server web
define('PS_CONST_URL_SERVER', 'https://quanly.nvoting.com');

define('PS_CONST_URL_WEB_SERVER', 'https://quanly.nvoting.com/web');

define('PS_CONST_URL_WEB_SERVER_UPLOAD', 'https://quanly.nvoting.com/media-service');

define('PS_CONST_API_URL_AVATAR', 'https://quanly.nvoting.com/media-service/avatar');

define('PS_CONST_API_URL_PATH_CACHE_IMAGE', 'https://quanly.nvoting.com/cache/image/');

define('PS_CONST_API_URL_PATH_CARD_BIRTHDAY', 'https://quanly.nvoting.com/card_birthday/image/');

// Avatar mac dinh chung
define('PS_CONST_API_URL_IMAGE_DEFAULT_AVATAR', 'https://quanly.nvoting.com/cache/image/avatar_default.png');

define('PS_CONST_API_URL_IMAGE_DEFAULT_NOTLOGO', 'https://quanly.nvoting.com/cache/image/no_logo_default.png');

define('PS_CONST_API_URL_IMAGE_DEFAULT_APPLOGO', 'https://quanly.nvoting.com/cache/image/app_logo_default.png');

define('PS_CONST_API_URL_IMAGE_DEFAULT_AVATAR_STUDENT', 'https://quanly.nvoting.com/cache/image/avatar_default.png');

define('PS_CONST_API_URL_IMAGE_DEFAULT_AVATAR_STUDENT_NO_OUT', 'https://quanly.nvoting.com/cache/image/not_save_text.png');

define('PS_CONST_API_URL_IMAGE_DEFAULT_AVATAR_STUDENT_MALE', 'https://quanly.nvoting.com/cache/image/avatar_default_male.png');

define('PS_CONST_API_URL_IMAGE_DEFAULT_AVATAR_STUDENT_FEMALE', 'https://quanly.nvoting.com/cache/image/avatar_default_female.png');

define('PS_CONST_API_URL_IMAGE_NO', 'https://quanly.nvoting.com/cache/image/no_img.png');

define('PS_CONST_API_URL_ALBUM_IMAGE_NO', 'https://quanly.nvoting.com/cache/image/no_img_album.png');

define('PS_CONST_API_URL_ALBUM_NOT_PUBLIC', 'https://quanly.nvoting.com/cache/image/album_not_public.png');

define('PS_CONST_API_URL_ALBUM_LOCK', 'https://quanly.nvoting.com/cache/image/album_lock.png');

//action show img by binary
define('PS_CONST_API_URL_IMAGE', 'https://quanly.nvoting.com/media-service/image_show');

// Url reset pass
define('PS_CONST_API_URL_RESET_PASS', 'http://ser01-k.kidsschool.vn');

// domain lib media public
define('PS_URL_LIB_MEDIA', 'https://ser02-k.kidsschool.vn');

// URL Media alias
define('PS_CONST_URL_MEDIA', 'https://quanly.nvoting.com/media');

// URL Media alias for Article
define('PS_CONST_URL_MEDIA_ARTICLE', 'https://quanly.nvoting.com/media-articles');
//define('PS_CONST_URL_MEDIA_ARTICLE', 'https://quanly.nvoting.com/web/uploads/cms_articles');




