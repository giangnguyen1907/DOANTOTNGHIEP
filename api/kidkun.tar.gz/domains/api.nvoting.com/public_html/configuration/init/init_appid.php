<?php
// ID cua app tren Play va Store
$apps_id = array(
		'com.kidsschool.android' => array('name' => 'KidsSchool' , 'version' => '2.0.2.d', 'urlApp' => 'https://play.google.com/store/apps/details?id=com.kidsschool.android'),// app PH
		'com.kidsschoolteacher.android' => array('name' => 'KidsSchool Teacher' , 'version' =>'2.0.2.e', 'urlApp' => 'https://play.google.com/store/apps/details?id=com.kidsschoolteacher.android'),// app GV
		'com.kidsschool.ios' => array('name' => 'KidsSchool' , 'version' =>'2.0.5', 'urlApp' => 'https://apps.apple.com/vn/app/kidsschool/id1329538517'),// KidsSchool: https://apps.apple.com/vn/app/kidsschool/id1329538517
		'com.kidsschoolteacher.ios' => array('name' => 'KidsSchool Teacher' , 'version' =>'2.0.5', 'urlApp' => 'https://apps.apple.com/vn/app/kidsschool-teacher/id1329539100'),// KidsSchool Teacher: https://apps.apple.com/vn/app/kidsschool-teacher/id1329539100
		);