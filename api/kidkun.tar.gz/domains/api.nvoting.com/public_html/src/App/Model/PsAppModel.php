<?php
/**
* @package truongnet.com
* @subpackage API app 
* @file PsAppModel.php
* 
* @author thangnc
* @version 1.0 2017/03/17
*/
namespace  App\Model;


class PsAppModel extends BaseModel {
	
}



