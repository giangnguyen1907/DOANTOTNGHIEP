<?php
/**
 * @package truongnet.com
 * @subpackage API app 
 * @file PsForgotPasswordModel.php
 * 
 * @author thangnc
 * @version 1.0 2017/03/17
 */
namespace App\Model;


class PsForgotPasswordModel extends BaseModel {
		
	protected $table = CONST_TBL_GUARD_FORGOT_PASSWORD;

}