<?php
/**
* @package			truongnet.com
* @subpackage     	API app 
*
* @file PsLogtimesModel.php
* @author thangnc
* @version 1.0 27-02-2017 -  00:51:34
*/
namespace  Api\Students\Model;

//use Illuminate\Database\Eloquent\Model;

use App\Model\BaseModel;

class PsLogtimesModel extends BaseModel {
	
	protected $table = CONST_TBL_PS_LOGTIMES;

	
}