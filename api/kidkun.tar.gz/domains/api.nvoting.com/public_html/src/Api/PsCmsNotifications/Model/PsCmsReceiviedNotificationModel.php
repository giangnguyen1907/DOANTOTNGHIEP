<?php

namespace Api\PsCmsNotifications\Model;

use App\Model\BaseModel;

class PsCmsReceivedNotificationModel extends BaseModel {
	
	protected $table = TBL_PS_CMS_RECEIVED_NOTIFICATION;
	
	

}