<?php

namespace Api\PsCmsNotifications\Model;

use App\Model\BaseModel;

class PsCmsNotificationsModel extends BaseModel {
	
	protected $table = TBL_PS_CMS_NOTIFICATIONS;
	

}